package com.lagou;

import com.lagou.bean.Book;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.cjk.CJKAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.Test;
import org.wltea.analyzer.lucene.IKAnalyzer;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class IKTest {
    @Test
    public void testCreateIndex() throws Exception {
        // 1. 采集数据
        List<Book> bookList = new ArrayList<Book>();
        Book  booka  = new Book();
        booka.setId(1);
        booka.setDesc("我是拉勾人啊");
        booka.setName("Lucene");
        booka.setPrice(100.45f);
        bookList.add(booka);


        // 2. 创建Document文档对象
        List<Document> documents = new ArrayList<>();
        for (Book book : bookList) {
            Document document = new Document();
            // Document文档中添加Field域
            // 图书Id   Store.YES:表示存储到文档域中
            document.add(new TextField("id", book.getId().toString(), Field.Store.YES));
            document.add(new TextField("name", book.getName(),
                    Field.Store.YES));
            document.add(new TextField("price", book.getPrice().toString(),
                    Field.Store.YES));
            document.add(new TextField("desc", book.getDesc(),
                    Field.Store.YES));
            // 把Document放到list中
            documents.add(document);
        }
        // 3. 创建Analyzer分词器,分析文档，对文档进行分词
         Analyzer analyzer = new IKAnalyzer();
       // Analyzer analyzer  =  new StandardAnalyzer();
        // Analyzer  analyzer  = new CJKAnalyzer();

        //  创建Directory对象,声明索引库的位置
        Directory directory = FSDirectory.open(Paths.get("D:/lucene/index2"));
        //  创建IndexWriteConfig对象，写入索引需要的配置
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        // 4.创建IndexWriter写入对象  添加文档对象document
        IndexWriter indexWriter = new IndexWriter(directory, config);

        for (Document doc : documents) {
            indexWriter.addDocument(doc);
        }
        // 释放资源
        indexWriter.close();
    }

}
