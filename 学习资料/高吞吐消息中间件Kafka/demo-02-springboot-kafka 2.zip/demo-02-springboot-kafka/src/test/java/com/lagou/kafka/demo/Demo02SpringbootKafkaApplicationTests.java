package com.lagou.kafka.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo02SpringbootKafkaApplicationTests {

    @Test
    void contextLoads() {
    }

}
