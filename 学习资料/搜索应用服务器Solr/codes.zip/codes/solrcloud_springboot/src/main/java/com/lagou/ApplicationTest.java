package com.lagou;

import com.lagou.bean.Book;
import com.lagou.service.BookService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

@SpringBootApplication
public class ApplicationTest {
    public static void main(String[] args) {
        ApplicationContext  app = SpringApplication.run(ApplicationTest.class,args);
        BookService  bookService = app.getBean("bookService",BookService.class);
        Book  book  = new Book("72","ES","ES就是ElasticSearch",911.5);
        bookService.addBook(book);
        List<Book>  books = bookService.queryBooks("name:*");
        System.out.println(books);
    }
}
