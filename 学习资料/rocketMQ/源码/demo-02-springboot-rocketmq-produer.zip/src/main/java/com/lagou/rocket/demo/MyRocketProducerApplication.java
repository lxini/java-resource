package com.lagou.rocket.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyRocketProducerApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyRocketProducerApplication.class, args);
    }
}
