package com.lagou.rocket.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyRocketConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyRocketConsumerApplication.class, args);
    }

}
