package com.lagou.rocket.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoNameserverrServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
