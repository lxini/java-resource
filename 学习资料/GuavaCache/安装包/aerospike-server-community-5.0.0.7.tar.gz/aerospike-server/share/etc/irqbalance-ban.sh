#!/bin/bash

if [ -d ${1}/net ]; then
    echo 'ban=true'
fi
