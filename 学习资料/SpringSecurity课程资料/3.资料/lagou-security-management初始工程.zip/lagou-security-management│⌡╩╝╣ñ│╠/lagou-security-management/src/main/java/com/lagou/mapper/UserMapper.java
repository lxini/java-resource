package com.lagou.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.domain.User;

public interface UserMapper extends BaseMapper<User> {
}