package com.lagou.dockerdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.dockerdemo.entity.Tbuser;

public interface UserMapper extends BaseMapper<Tbuser> {
}
