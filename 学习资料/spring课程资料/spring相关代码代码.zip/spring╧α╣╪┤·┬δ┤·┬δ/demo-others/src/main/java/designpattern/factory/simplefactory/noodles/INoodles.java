package designpattern.factory.simplefactory.noodles;

public interface INoodles {
    /**
     * 描述每种面条啥样的
     */
    public abstract void desc();
}
