package aop;

/**
 * @author 应癫
 */
public class Pig extends  Animal{


    public static void main(String[] args) {
        Pig pig = new Pig();
        pig.eat();
        pig.run();
    }
}
