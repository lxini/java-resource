package aop;

/**
 * @author 应癫
 */
public class Horse extends  Animal{

    public static void main(String[] args) {
        Horse horse = new Horse();
        horse.eat();
        horse.run();
    }
}
