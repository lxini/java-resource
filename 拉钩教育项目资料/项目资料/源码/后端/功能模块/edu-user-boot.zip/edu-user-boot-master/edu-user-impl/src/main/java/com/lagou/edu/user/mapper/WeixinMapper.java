package com.lagou.edu.user.mapper;

import com.lagou.edu.user.entity.Weixin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author leo
 * @since 2020-06-27
 */
public interface WeixinMapper extends BaseMapper<Weixin> {

}
