package com.lagou.edu.user.service;

import com.lagou.edu.user.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author leo
 * @since 2020-06-22
 */
public interface IUserService extends IService<User> {

}
