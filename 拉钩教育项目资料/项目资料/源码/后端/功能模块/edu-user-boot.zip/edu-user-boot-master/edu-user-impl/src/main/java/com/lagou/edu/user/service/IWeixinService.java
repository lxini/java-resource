package com.lagou.edu.user.service;

import com.lagou.edu.user.entity.Weixin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author leo
 * @since 2020-06-27
 */
public interface IWeixinService extends IService<Weixin> {

}
