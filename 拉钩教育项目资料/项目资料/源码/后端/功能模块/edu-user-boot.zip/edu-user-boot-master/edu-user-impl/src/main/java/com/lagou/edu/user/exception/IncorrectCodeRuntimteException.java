package com.lagou.edu.user.exception;

public class IncorrectCodeRuntimteException extends RuntimeException{


    public IncorrectCodeRuntimteException(String message) {
        super(message);
    }
}
