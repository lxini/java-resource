package com.lagou.edu.user.exception;

public class ExpireCodeRuntimeException extends RuntimeException{


    public ExpireCodeRuntimeException(String message) {
        super(message);
    }
}
