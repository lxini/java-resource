package com.lagou.edu.ad.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author leo
 * @since 2020-06-18
 */
@RestController
@RequestMapping("/ad/promotion-ad")
public class PromotionAdController {

}
