package com.lagou.edu.pay.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lagou.edu.pay.entity.PayOrderRecord;
/**
 * @author: ma wei long
 * @date:   2020年6月22日 上午12:25:53
 */
public interface IPayOrderRecordService extends IService<PayOrderRecord>{
}
