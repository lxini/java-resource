package com.lagou.edu.pay.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.edu.pay.entity.PayOrderRecord;

/**
 * @author: ma wei long
 * @date:   2020年6月22日 上午12:25:01
 */
public interface PayOrderRecordMapper extends BaseMapper<PayOrderRecord> {
}