package com.lagou.edu.pay.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.edu.pay.entity.PayOrder;

/**
 * @author: ma wei long
 * @date:   2020年6月17日 上午11:19:08
 */
public interface PayOrderMapper extends BaseMapper<PayOrder> {
}