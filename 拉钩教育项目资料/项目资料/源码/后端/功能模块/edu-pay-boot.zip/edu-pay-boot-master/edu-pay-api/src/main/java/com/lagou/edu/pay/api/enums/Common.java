package com.lagou.edu.pay.api.enums;

/**
 * @Author: lixiangyong
 * @Description 通用枚举接口
 * @Date: 2018/9/17 下午7:33
 **/
public interface Common {
    Integer getCode();
    String getName();
}
