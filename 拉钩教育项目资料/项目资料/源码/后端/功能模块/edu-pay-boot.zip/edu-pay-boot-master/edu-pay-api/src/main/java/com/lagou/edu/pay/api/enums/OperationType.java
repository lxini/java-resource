package com.lagou.edu.pay.api.enums;

/**
 * @author: ma wei long
 * @date:   2020年6月22日 下午2:01:57
 */
public enum OperationType{
	CREATE,//创建
	PAY;//支付
}
