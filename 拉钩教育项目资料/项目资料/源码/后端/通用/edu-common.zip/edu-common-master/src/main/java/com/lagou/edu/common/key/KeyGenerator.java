package com.lagou.edu.common.key;

public interface KeyGenerator {

    Number generateKey();

}
