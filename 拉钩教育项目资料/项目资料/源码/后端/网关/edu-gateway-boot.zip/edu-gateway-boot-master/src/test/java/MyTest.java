
import java.time.ZonedDateTime;

public class MyTest {
    public void testTime() {
        ZonedDateTime zonedDateTime = ZonedDateTime.now();
        System.out.println(zonedDateTime);
    }
}
