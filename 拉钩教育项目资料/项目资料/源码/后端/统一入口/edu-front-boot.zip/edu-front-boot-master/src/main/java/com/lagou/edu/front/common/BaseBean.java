package com.lagou.edu.front.common;

import java.io.Serializable;

/**
 * bean的基础类
 */
public interface BaseBean extends Serializable {

}