<template>
  <home-advertise-detail :isEdit="false"></home-advertise-detail>
</template>
<script>
import HomeAdvertiseDetail from './AdvertiseSpaceDetail'
export default {
  name: 'addHomeAdvertise',
  title: '添加广告位',
  components: { HomeAdvertiseDetail }
}
</script>
<style></style>
