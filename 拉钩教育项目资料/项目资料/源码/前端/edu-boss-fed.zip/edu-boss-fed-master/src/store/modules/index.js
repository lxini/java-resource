import courses from './courses'
import sections from './sections'
import lessons from './lessons'
import users from './users'
import options from './options'

export default { courses, sections, lessons, users, options }
