/**
 * Initial state
 */
const state = {

}

/**
 * Getters
 * @type {import('vuex/types').GetterTree<typeof state}
 */
const getters = {

}

/**
 * Mutations
 * @type {import('vuex/types').MutationTree<typeof state}
 */
const mutations = {

}

/**
 * Actions
 * @type {import('vuex/types').ActionTree<typeof state}
 */
const actions = {

}

// Export module
export default { state, getters, mutations, actions }
