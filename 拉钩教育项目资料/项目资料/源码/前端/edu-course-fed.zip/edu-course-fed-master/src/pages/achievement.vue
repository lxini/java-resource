<template>
    <div class="achievement">
        <div class="achievement-top">
            <div class="achievement-info">
                <div class="achievement-info-score">
                    28
                </div>
                <div class="achievement-info-unit">
                    学分
                </div>
            </div>
        </div>
        <div class="achievement-top-body">
            <ul class="achievement-list">
                <li class="achievement-list-item">
                    <div class="achievement-list-top">
                        <div class="left-icon">
                            <img
                                src=""
                                alt=""
                            >
                        </div>
                        <div class="title-info">
                            <div class="title">
                                开启新技能
                            </div>
                            <div class="des">
                                加入课程学习，获得成就
                            </div>
                        </div>
                        <div class="right-icon">
                            <img
                                src=""
                                alt=""
                            >
                        </div>
                    </div>
                    <div class="achievement-list-body">
                        <div class="title">
                            我在《拉勾教育》学习的第1门课程
                        </div>
                        <div class="content">
                            <div class="left">
                                <img
                                    src=""
                                    alt=""
                                    class="left-icon"
                                >
                            </div>
                            <div class="right">
                                <div class="title">
                                    Vue中修改了数组数值
                                </div>
                                <div class="title">
                                    7天成长训练营
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="achievement-list-bottom">
                        <button class="achievement-list-bottom-btn">
                            领取1学分
                        </button>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
    export default {

    };
</script>

<style lang="less" scoped>

</style>