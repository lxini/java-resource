export const ALI_PLAYER = 'ALI_PLAYER';
export const TC_PLAYER = 'TC_PLAYER';
export const ALIPLAYER_AUTH_EXPIREDTIME = 80 * 1000; // 默认是100s 最大是300s
