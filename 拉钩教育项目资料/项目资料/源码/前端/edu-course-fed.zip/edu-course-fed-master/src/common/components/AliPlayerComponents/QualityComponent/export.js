import QualityComponent from '.';

if (!window.AliPlayerComponent) {
    window.AliPlayerComponent = {};
}
window.AliPlayerComponent.QualityComponent = QualityComponent;
