## 倍速播放组件

其他语言: [English](https://github.com/aliyunvideo/AliyunPlayer_Web/blob/master/customComponents/src/components/RateComponent/README.md)

倍速播放组件是用来快速调整视频速度的组件度

### 使用方法

引用当前组件, 播放器配置中添加如下代码:

```js
components: [{
  name: 'RateComponent',
  type: AliPlayerComponent.RateComponent
}]
```

**添加倍速播放组件之后, 播放器的设置里面的倍速选项会被隐藏**
