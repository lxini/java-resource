window.appBeforeGoBack = window.appBeforeGoBack || (
    () => {
        return true; // 确认后退返回true
    }
);
// window.appBeforeUnLoaded = window.appBeforeUnLoaded || (
//     () => {
//     }
// );
