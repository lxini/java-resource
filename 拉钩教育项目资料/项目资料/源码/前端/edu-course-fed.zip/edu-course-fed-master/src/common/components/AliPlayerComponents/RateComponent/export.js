import RateComponent from './index.js';

if (!window.AliPlayerComponent) {
    window.AliPlayerComponent = {};
}
window.AliPlayerComponent.RateComponent = RateComponent;