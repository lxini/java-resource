<template>
    <div class="footer">
        如有任何问题，请联系微信：lagouandy
    </div>
</template>

<script>
export default {
    name: 'MobileFooter'
};
</script>

<style scoped>
    .footer{
        height: 120px;
        line-height: 120px;
        text-align: center;
        background-color: #f8f9fa;
        font-size: 24px;
        color: #999;
    }
</style>