// https://eslint.org/docs/user-guide/configuring
// base https://github.com/wangjinyang/eslint-plugin-lagou

// module.exports = {
//   root: true,
//   extends: ['plugin:lagou/vue'],
//   // check if imports actually resolve
//   'settings': {
//     'import/resolver': {
//       'webpack': {
//         'config': 'build/webpack.base.conf.js'
//       }
//     }
//   },
//   // add your custom rules here
//   'rules': {
//     'template-curly-spacing': 'off',
//     indent: 'off'
//     // 'no-debugger': process.env.NODE_ENV === 'production' ? 2 : 0,
//   }
// };
