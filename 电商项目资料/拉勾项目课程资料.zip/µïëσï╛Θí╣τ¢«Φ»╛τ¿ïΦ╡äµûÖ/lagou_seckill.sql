/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.7.26-log : Database - lagou_seckill
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lagou_seckill` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `lagou_seckill`;

/*Table structure for table `tb_seckill_goods` */

DROP TABLE IF EXISTS `tb_seckill_goods`;

CREATE TABLE `tb_seckill_goods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `goods_id` bigint(20) DEFAULT NULL COMMENT 'spu ID',
  `item_id` bigint(20) DEFAULT NULL COMMENT 'sku ID',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `small_pic` varchar(150) DEFAULT NULL COMMENT '商品图片',
  `price` decimal(10,2) DEFAULT NULL COMMENT '原价格',
  `cost_price` decimal(10,2) DEFAULT NULL COMMENT '秒杀价格',
  `seller_id` varchar(100) DEFAULT NULL COMMENT '商家ID',
  `create_time` datetime DEFAULT NULL COMMENT '添加日期',
  `check_time` datetime DEFAULT NULL COMMENT '审核日期',
  `status` char(1) DEFAULT NULL COMMENT '审核状态，0未审核，1审核通过，2审核不通过',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `num` int(11) DEFAULT NULL COMMENT '秒杀商品数',
  `stock_count` int(11) DEFAULT NULL COMMENT '剩余库存数',
  `introduction` varchar(2000) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10028 DEFAULT CHARSET=utf8;

/*Data for the table `tb_seckill_goods` */

insert  into `tb_seckill_goods`(`id`,`goods_id`,`item_id`,`title`,`small_pic`,`price`,`cost_price`,`seller_id`,`create_time`,`check_time`,`status`,`start_time`,`end_time`,`num`,`stock_count`,`introduction`) values (10020,NULL,100000004580,'薇妮(viney)女士单肩包 时尚牛皮女包百搭斜挎包女士手提大包(经典黑)',NULL,87900.00,900.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:35','1','2021-05-07 20:00:00','2021-05-07 21:59:59',100,70,'老板跑路,吐血甩卖！'),(10021,NULL,100000006163,'巴布豆(BOBDOG)柔薄悦动婴儿拉拉裤XXL码80片(15kg以上)',NULL,67100.00,100.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:35','1','2021-05-07 20:00:00','2021-05-07 21:59:59',100,70,'老板跑路,吐血甩卖！'),(10022,NULL,100000015158,'华为 HUAWEI 麦芒7 6G+64G 魅海蓝 全网通  前置智慧双摄  移动联通电信4G手机 双卡双待',NULL,40800.00,800.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:35','1','2021-05-07 14:00:00','2021-05-07 15:59:59',100,0,'老板跑路,吐血甩卖！'),(10023,NULL,100000030074,'夕阳红防蓝光老花镜男女通用款 清新灰色时尚大框镜架不易折断老花眼镜E9004G 200度 灰色',NULL,99800.00,800.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:35','1','2021-05-07 14:00:00','2021-05-07 15:59:59',100,0,'老板跑路,吐血甩卖！'),(10024,NULL,100000030628,'ARNO防蓝光老花镜女 远近两用智能自动变焦渐进多焦点老光眼镜A1005 300度 亮紫色',NULL,11300.00,300.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:31','1','2021-05-07 16:00:00','2021-05-07 17:59:59',100,70,'老板跑路,吐血甩卖！'),(10025,NULL,100000047372,'努比亚 nubia Z18 全面屏3.0 极夜黑 6GB+64GB 全网通 移动联通电信4G手机 双卡双待',NULL,83000.00,99.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:31','1','2021-05-07 16:00:00','2021-05-07 17:59:59',100,70,'老板跑路,吐血甩卖！'),(10026,NULL,100000056817,'森马（Semir） 牛仔裤女 2018秋季新款粉红豹长裤潮流破洞裤子刺绣显瘦 19078240802 牛仔黑 27',NULL,18600.00,86.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:31','1','2021-05-07 18:00:00','2021-05-07 19:59:59',100,70,'老板跑路,吐血甩卖！'),(10027,NULL,100000060433,'娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3001 黑色(A0) 27',NULL,7300.00,300.00,NULL,'2021-05-07 13:10:31','2021-05-07 13:10:31','1','2021-05-07 18:00:00','2021-05-07 19:59:59',100,0,'老板跑路,吐血甩卖！');

/*Table structure for table `tb_seckill_order` */

DROP TABLE IF EXISTS `tb_seckill_order`;

CREATE TABLE `tb_seckill_order` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `seckill_id` bigint(20) DEFAULT NULL COMMENT '秒杀商品ID',
  `money` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `user_id` varchar(50) DEFAULT NULL COMMENT '用户',
  `seller_id` varchar(50) DEFAULT NULL COMMENT '商家',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `status` char(1) DEFAULT NULL COMMENT '状态，0未支付，1已支付',
  `receiver_address` varchar(200) DEFAULT NULL COMMENT '收货人地址',
  `receiver_mobile` varchar(20) DEFAULT NULL COMMENT '收货人电话',
  `receiver` varchar(20) DEFAULT NULL COMMENT '收货人',
  `transaction_id` varchar(30) DEFAULT NULL COMMENT '交易流水',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_seckill_order` */

insert  into `tb_seckill_order`(`id`,`seckill_id`,`money`,`user_id`,`seller_id`,`create_time`,`pay_time`,`status`,`receiver_address`,`receiver_mobile`,`receiver`,`transaction_id`) values (1390608308850790400,10027,300.00,'yuanjing',NULL,'2021-05-07 10:03:52','2021-05-07 10:06:19','1',NULL,NULL,NULL,'2021050722001408400500922777');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
