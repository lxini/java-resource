/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.7.26-log : Database - lagou_order
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lagou_order` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `lagou_order`;

/*Table structure for table `tb_category_report` */

DROP TABLE IF EXISTS `tb_category_report`;

CREATE TABLE `tb_category_report` (
  `category_id1` int(11) NOT NULL COMMENT '1级分类',
  `category_id2` int(11) NOT NULL COMMENT '2级分类',
  `category_id3` int(11) NOT NULL COMMENT '3级分类',
  `count_date` date NOT NULL COMMENT '统计日期',
  `num` int(11) DEFAULT NULL COMMENT '销售数量',
  `money` int(11) DEFAULT NULL COMMENT '销售额',
  PRIMARY KEY (`category_id1`,`category_id2`,`category_id3`,`count_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `tb_category_report` */

insert  into `tb_category_report`(`category_id1`,`category_id2`,`category_id3`,`count_date`,`num`,`money`) values (1,4,5,'2019-01-26',1,300),(74,7,8,'2019-01-26',5,900);

/*Table structure for table `tb_order` */

DROP TABLE IF EXISTS `tb_order`;

CREATE TABLE `tb_order` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '订单id',
  `total_num` int(11) DEFAULT NULL COMMENT '数量合计',
  `total_money` int(11) DEFAULT NULL COMMENT '金额合计',
  `pre_money` int(11) DEFAULT NULL COMMENT '优惠金额',
  `post_fee` int(11) DEFAULT NULL COMMENT '邮费',
  `pay_money` int(11) DEFAULT NULL COMMENT '实付金额',
  `pay_type` varchar(1) COLLATE utf8_bin DEFAULT NULL COMMENT '支付类型，1、在线支付、0 货到付款',
  `create_time` datetime DEFAULT NULL COMMENT '订单创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '订单更新时间',
  `pay_time` datetime DEFAULT NULL COMMENT '付款时间',
  `consign_time` datetime DEFAULT NULL COMMENT '发货时间',
  `end_time` datetime DEFAULT NULL COMMENT '交易完成时间',
  `close_time` datetime DEFAULT NULL COMMENT '交易关闭时间',
  `shipping_name` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '物流名称',
  `shipping_code` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '物流单号',
  `username` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '用户名称',
  `buyer_message` varchar(1000) COLLATE utf8_bin DEFAULT NULL COMMENT '买家留言',
  `buyer_rate` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '是否评价',
  `receiver_contact` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '收货人',
  `receiver_mobile` varchar(12) COLLATE utf8_bin DEFAULT NULL COMMENT '收货人手机',
  `receiver_address` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '收货人地址',
  `source_type` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '订单来源：1:web，2：app，3：微信公众号，4：微信小程序  5 H5手机页面',
  `transaction_id` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '交易流水号',
  `order_status` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '订单状态',
  `pay_status` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '支付状态',
  `consign_status` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '发货状态',
  `is_delete` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`),
  KEY `status` (`order_status`),
  KEY `payment_type` (`pay_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `tb_order` */

insert  into `tb_order`(`id`,`total_num`,`total_money`,`pre_money`,`post_fee`,`pay_money`,`pay_type`,`create_time`,`update_time`,`pay_time`,`consign_time`,`end_time`,`close_time`,`shipping_name`,`shipping_code`,`username`,`buyer_message`,`buyer_rate`,`receiver_contact`,`receiver_mobile`,`receiver_address`,`source_type`,`transaction_id`,`order_status`,`pay_status`,`consign_status`,`is_delete`) values ('1390560240596029440',2,13400,NULL,NULL,13400,'1','2021-05-07 06:52:51','2021-05-07 06:53:57','2021-05-07 06:55:37',NULL,NULL,NULL,NULL,NULL,'yuanjing',NULL,'0','老元','110','北京市房山区绿地诺亚方舟','1','2021050722001408400500922771','1','1','0','0');

/*Table structure for table `tb_order_config` */

DROP TABLE IF EXISTS `tb_order_config`;

CREATE TABLE `tb_order_config` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `order_timeout` int(11) DEFAULT NULL COMMENT '正常订单超时时间（分）',
  `seckill_timeout` int(11) DEFAULT NULL COMMENT '秒杀订单超时时间（分）',
  `take_timeout` int(11) DEFAULT NULL COMMENT '自动收货（天）',
  `service_timeout` int(11) DEFAULT NULL COMMENT '售后期限',
  `comment_timeout` int(11) DEFAULT NULL COMMENT '自动五星好评',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_order_config` */

insert  into `tb_order_config`(`id`,`order_timeout`,`seckill_timeout`,`take_timeout`,`service_timeout`,`comment_timeout`) values (1,60,10,15,7,7);

/*Table structure for table `tb_order_item` */

DROP TABLE IF EXISTS `tb_order_item`;

CREATE TABLE `tb_order_item` (
  `id` varchar(20) COLLATE utf8_bin NOT NULL COMMENT 'ID',
  `category_id1` int(11) DEFAULT NULL COMMENT '1级分类',
  `category_id2` int(11) DEFAULT NULL COMMENT '2级分类',
  `category_id3` int(11) DEFAULT NULL COMMENT '3级分类',
  `spu_id` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT 'SPU_ID',
  `sku_id` varchar(20) COLLATE utf8_bin NOT NULL COMMENT 'SKU_ID',
  `order_id` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '订单ID',
  `name` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '商品名称',
  `price` int(20) DEFAULT NULL COMMENT '单价',
  `num` int(10) DEFAULT NULL COMMENT '数量',
  `money` int(20) DEFAULT NULL COMMENT '总金额',
  `pay_money` int(11) DEFAULT NULL COMMENT '实付金额',
  `image` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '图片地址',
  `weight` int(11) DEFAULT NULL COMMENT '重量',
  `post_fee` int(11) DEFAULT NULL COMMENT '运费',
  `is_return` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '是否退货',
  PRIMARY KEY (`id`),
  KEY `item_id` (`sku_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `tb_order_item` */

insert  into `tb_order_item`(`id`,`category_id1`,`category_id2`,`category_id3`,`spu_id`,`sku_id`,`order_id`,`name`,`price`,`num`,`money`,`pay_money`,`image`,`weight`,`post_fee`,`is_return`) values ('1387027180017553408',439,440,457,'10000006043500','100000060435','1387027178167865344','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387053444170387456',439,440,457,'10000006043500','100000060435','1387053443750957056','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387062885791961088',439,440,457,'10000006043500','100000060435','1387062885204758528','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387063506003693568',439,440,457,'10000006043500','100000060435','1387063505592651776','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387064560686600192',439,440,457,'10000006043500','100000060435','1387064560573353984','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387065154591657984',439,440,457,'10000006043500','100000060435','1387065154470023168','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387065842080026624',439,440,457,'10000006043500','100000060435','1387065841954197504','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387234309307502592',439,440,457,'10000006043500','100000060435','1387234309181673472','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387236873507835904',439,440,457,'10000006043500','100000060435','1387236872991936512','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387237904677474304',439,440,457,'10000006043500','100000060435','1387237904325152768','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387241371273924608',439,440,457,'10000006043500','100000060435','1387241371164872704','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387241888578408448',439,440,457,'10000006043500','100000060435','1387241888129617920','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387242558870130688',439,440,457,'10000006043500','100000060435','1387242558765273088','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387325683545542656',439,440,457,'10000006043500','100000060435','1387325681943318528','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387326045346205696',439,440,457,'10000006043500','100000060435','1387326044964524032','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387327493958144000',439,440,457,'10000006043500','100000060435','1387327492985065472','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387327736590241792',439,440,457,'10000006043500','100000060435','1387327735860432896','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387327952001306624',439,440,457,'10000006043500','100000060435','1387327951523155968','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387333503556915200',439,440,457,'10000006043500','100000060435','1387333500633485312','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387334277309534208',439,440,457,'10000006043500','100000060435','1387334276948824064','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387335467338436608',439,440,457,'10000006043500','100000060435','1387335466948366336','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387336141660884992',439,440,457,'10000006043500','100000060435','1387336141325340672','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387336798912516096',439,440,457,'10000006043500','100000060435','1387336798803464192','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387342742849458176',439,440,457,'10000006043500','100000060435','1387342742497136640','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387343152716845056',439,440,457,'10000006043500','100000060435','1387343152410660864','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387343525024239616',439,440,457,'10000006043500','100000060435','1387343524726444032','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387351171638890496',439,440,457,'10000006043500','100000060435','1387351171538227200','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387611574394556416',439,440,457,'10000006043500','100000060435','1387611574071595008','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387612260360392704',439,440,457,'10000006043500','100000060435','1387612260238757888','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387613103688126464',439,440,457,'10000006043500','100000060435','1387613103574880256','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1387613898328379392',439,440,457,'10000006043500','100000060435','1387613898223521792','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390503120404090880',439,440,457,'10000006043500','100000060435','1390503119795916800','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390504743121588224',439,440,457,'10000006043500','100000060435','1390504743033507840','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390533204557041664',439,440,457,'10000006043500','100000060435','1390533204414435328','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390544256321589248',439,440,457,'10000006043500','100000060435','1390544256111874048','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390545439853514752',439,440,457,'10000006043500','100000060435','1390545439480221696','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390546438718623744',439,440,457,'10000006043500','100000060435','1390546438374690816','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390546745657790464',439,440,457,'10000006043500','100000060435','1390546745552932864','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0'),('1390560241493610496',439,440,457,'10000006043500','100000060435','1390560240596029440','娅丽达 YERAD 高腰铅笔裤女2018秋季新款牛仔裤女紧身显瘦小脚长裤H3101 黑色(A0) 27',6700,2,13400,13400,'https://m.360buyimg.com/mobilecms/s720x720_jfs/t22864/187/2485738327/313668/e5649878/5b839f16N3f5dd94d.jpg!q70.jpg.webp',20,NULL,'0');

/*Table structure for table `tb_order_log` */

DROP TABLE IF EXISTS `tb_order_log`;

CREATE TABLE `tb_order_log` (
  `id` varchar(20) NOT NULL COMMENT 'ID',
  `operater` varchar(50) DEFAULT NULL COMMENT '操作员',
  `operate_time` datetime DEFAULT NULL COMMENT '操作时间',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单ID',
  `order_status` char(1) DEFAULT NULL COMMENT '订单状态',
  `pay_status` char(1) DEFAULT NULL COMMENT '付款状态',
  `consign_status` char(1) DEFAULT NULL COMMENT '发货状态',
  `remarks` varchar(100) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_order_log` */

insert  into `tb_order_log`(`id`,`operater`,`operate_time`,`order_id`,`order_status`,`pay_status`,`consign_status`,`remarks`) values ('1387027503717158912','system','2021-04-27 12:55:01',1387027178167865344,'1','1',NULL,'Alipay流水:2021042722001408400500917118'),('1387064087174844416','system','2021-04-27 15:20:23',1387063505592651776,'1','1',NULL,'Alipay流水:2021042722001408400500917120'),('1387235367224217600','system','2021-04-28 02:41:00',1387234309181673472,'1','1',NULL,'Alipay流水:2021042822001408400500917281'),('1387326672176549888','system','2021-04-28 08:43:49',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326674470834176','system','2021-04-28 08:43:49',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326675645239296','system','2021-04-28 08:43:49',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326677138411520','system','2021-04-28 08:43:50',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326678216347648','system','2021-04-28 08:43:50',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326679302672384','system','2021-04-28 08:43:50',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326680464494592','system','2021-04-28 08:43:51',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326681546625024','system','2021-04-28 08:43:51',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326682716835840','system','2021-04-28 08:43:51',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326683882852352','system','2021-04-28 08:43:51',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326685325692928','system','2021-04-28 08:43:52',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326686768533504','system','2021-04-28 08:43:52',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387326688202985472','system','2021-04-28 08:43:52',NULL,'4',NULL,NULL,'1387326044964524032订单已关闭'),('1387333592589406208','system','2021-04-28 09:11:19',NULL,'4',NULL,NULL,'1387333500633485312订单已关闭'),('1387334364035158016','system','2021-04-28 09:14:22',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334365838708736','system','2021-04-28 09:14:23',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334366790815744','system','2021-04-28 09:14:23',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334367705174016','system','2021-04-28 09:14:23',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334368653086720','system','2021-04-28 09:14:24',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334369571639296','system','2021-04-28 09:14:24',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334370431471616','system','2021-04-28 09:14:24',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334371274526720','system','2021-04-28 09:14:24',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334372079833088','system','2021-04-28 09:14:24',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334372922888192','system','2021-04-28 09:14:25',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334373778526208','system','2021-04-28 09:14:25',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334374604804096','system','2021-04-28 09:14:25',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387334744819240960','system','2021-04-28 09:15:53',NULL,'4',NULL,NULL,'1387334276948824064订单已关闭'),('1387335552969347072','system','2021-04-28 09:19:06',NULL,'4',NULL,NULL,'1387335466948366336订单已关闭'),('1387336227207909376','system','2021-04-28 09:21:47',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336228231319552','system','2021-04-28 09:21:47',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336228998877184','system','2021-04-28 09:21:47',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336229779017728','system','2021-04-28 09:21:47',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336230613684224','system','2021-04-28 09:21:47',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336231565791232','system','2021-04-28 09:21:48',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336232454983680','system','2021-04-28 09:21:48',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336233239318528','system','2021-04-28 09:21:48',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336234006876160','system','2021-04-28 09:21:48',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336234854125568','system','2021-04-28 09:21:49',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336235739123712','system','2021-04-28 09:21:49',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336236536041472','system','2021-04-28 09:21:49',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336470074888192','system','2021-04-28 09:22:45',NULL,'4',NULL,NULL,'1387336141325340672订单已关闭'),('1387336884140773376','system','2021-04-28 09:24:23',NULL,'4',NULL,NULL,'1387336798803464192订单已关闭'),('1387342829038211072','system','2021-04-28 09:48:01',NULL,'4',NULL,NULL,'1387342742497136640订单已关闭'),('1387343238142234624','system','2021-04-28 09:49:38',NULL,'4',NULL,NULL,'1387343152410660864订单已关闭'),('1387343618720796672','system','2021-04-28 09:51:09',NULL,'4',NULL,NULL,'1387343524726444032订单已关闭'),('1387351388115308544','system','2021-04-28 10:22:01',NULL,'4',NULL,NULL,'1387351171538227200订单已关闭'),('1387611785808449536','system','2021-04-29 03:36:45',NULL,'4',NULL,NULL,'1387611574071595008订单已关闭'),('1387614026145599488','system','2021-04-29 03:45:39',1387613898223521792,'1','1',NULL,'Alipay流水:2021042922001408400500918702'),('1390503489406373888','system','2021-05-07 03:07:21',1390503119795916800,'1','1',NULL,'Alipay流水:2021050722001408400500922203'),('1390504901246849024','system','2021-05-07 03:12:57',1390504743033507840,'1','1',NULL,'Alipay流水:2021050722001408400500922584'),('1390533783253553152','system','2021-05-07 05:07:43',1390533204414435328,'1','1',NULL,'Alipay流水:2021050722001408400500922764'),('1390544487398379520','system','2021-05-07 05:50:16',1390544256111874048,'1','1',NULL,'Alipay流水:2021050722001408400500922458'),('1390545593755111424','system','2021-05-07 05:54:39',1390545439480221696,'1','1',NULL,'Alipay流水:2021050722001408400500922765'),('1390546854927798272','system','2021-05-07 05:59:40',1390546745552932864,'1','1',NULL,'Alipay流水:2021050722001408400500922766'),('1390560517109714944','system','2021-05-07 06:53:57',1390560240596029440,'1','1',NULL,'Alipay流水:2021050722001408400500922771');

/*Table structure for table `tb_preferential` */

DROP TABLE IF EXISTS `tb_preferential`;

CREATE TABLE `tb_preferential` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `buy_money` int(11) DEFAULT NULL COMMENT '消费金额',
  `pre_money` int(11) DEFAULT NULL COMMENT '优惠金额',
  `category_id` bigint(20) DEFAULT NULL COMMENT '品类ID',
  `start_time` date DEFAULT NULL COMMENT '活动开始日期',
  `end_time` date DEFAULT NULL COMMENT '活动截至日期',
  `state` varchar(1) DEFAULT NULL COMMENT '状态',
  `type` varchar(1) DEFAULT NULL COMMENT '类型1不翻倍 2翻倍',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tb_preferential` */

insert  into `tb_preferential`(`id`,`buy_money`,`pre_money`,`category_id`,`start_time`,`end_time`,`state`,`type`) values (1,10000,3000,106,'2019-01-16','2029-07-13','1','1'),(2,30000,10000,106,'2019-01-16','2029-07-13','1','1'),(3,60000,30000,1124,'2019-01-16','2029-07-13','1','1'),(4,10000,4000,1124,'2019-01-16','2029-07-13','1','2');

/*Table structure for table `tb_return_cause` */

DROP TABLE IF EXISTS `tb_return_cause`;

CREATE TABLE `tb_return_cause` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `cause` varchar(100) DEFAULT NULL COMMENT '原因',
  `seq` int(11) DEFAULT '1' COMMENT '排序',
  `status` char(1) DEFAULT NULL COMMENT '是否启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_return_cause` */

/*Table structure for table `tb_return_order` */

DROP TABLE IF EXISTS `tb_return_order`;

CREATE TABLE `tb_return_order` (
  `id` bigint(20) NOT NULL COMMENT '服务单号',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单号',
  `apply_time` datetime DEFAULT NULL COMMENT '申请时间',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `user_account` varchar(11) DEFAULT NULL COMMENT '用户账号',
  `linkman` varchar(20) DEFAULT NULL COMMENT '联系人',
  `linkman_mobile` varchar(11) DEFAULT NULL COMMENT '联系人手机',
  `type` char(1) DEFAULT NULL COMMENT '类型',
  `return_money` int(11) DEFAULT NULL COMMENT '退款金额',
  `is_return_freight` char(1) DEFAULT NULL COMMENT '是否退运费',
  `status` char(1) DEFAULT NULL COMMENT '申请状态',
  `dispose_time` datetime DEFAULT NULL COMMENT '处理时间',
  `return_cause` int(11) DEFAULT NULL COMMENT '退货退款原因',
  `evidence` varchar(1000) DEFAULT NULL COMMENT '凭证图片',
  `description` varchar(1000) DEFAULT NULL COMMENT '问题描述',
  `remark` varchar(1000) DEFAULT NULL COMMENT '处理备注',
  `admin_id` int(11) DEFAULT NULL COMMENT '管理员id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_return_order` */

/*Table structure for table `tb_return_order_item` */

DROP TABLE IF EXISTS `tb_return_order_item`;

CREATE TABLE `tb_return_order_item` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `category_id` bigint(20) DEFAULT NULL COMMENT '分类ID',
  `spu_id` bigint(20) DEFAULT NULL COMMENT 'SPU_ID',
  `sku_id` bigint(20) NOT NULL COMMENT 'SKU_ID',
  `order_id` bigint(20) NOT NULL COMMENT '订单ID',
  `order_item_id` bigint(20) DEFAULT NULL COMMENT '订单明细ID',
  `return_order_id` bigint(20) NOT NULL COMMENT '退货订单ID',
  `title` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '标题',
  `price` int(20) DEFAULT NULL COMMENT '单价',
  `num` int(10) DEFAULT NULL COMMENT '数量',
  `money` int(20) DEFAULT NULL COMMENT '总金额',
  `pay_money` int(20) DEFAULT NULL COMMENT '支付金额',
  `image` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '图片地址',
  `weight` int(11) DEFAULT NULL COMMENT '重量',
  PRIMARY KEY (`id`),
  KEY `item_id` (`sku_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `tb_return_order_item` */

/*Table structure for table `undo_log` */

DROP TABLE IF EXISTS `undo_log`;

CREATE TABLE `undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_unionkey` (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `undo_log` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
