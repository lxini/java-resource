/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.7.26-log : Database - lagou_business
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lagou_business` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `lagou_business`;

/*Table structure for table `tb_activity` */

DROP TABLE IF EXISTS `tb_activity`;

CREATE TABLE `tb_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(200) DEFAULT NULL COMMENT '活动标题',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `status` char(1) DEFAULT NULL COMMENT '状态',
  `content` text COMMENT '活动内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_activity` */

/*Table structure for table `tb_ad` */

DROP TABLE IF EXISTS `tb_ad`;

CREATE TABLE `tb_ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) DEFAULT NULL COMMENT '广告名称',
  `position` varchar(50) DEFAULT NULL COMMENT '广告位置',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '到期时间',
  `status` char(1) DEFAULT NULL COMMENT '状态',
  `image` varchar(100) DEFAULT NULL COMMENT '图片地址',
  `url` varchar(100) DEFAULT NULL COMMENT 'URL',
  `remarks` varchar(1000) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tb_ad` */

insert  into `tb_ad`(`id`,`name`,`position`,`start_time`,`end_time`,`status`,`image`,`url`,`remarks`) values (1,'name1','web_index_lb','2021-03-03 12:54:41','2029-07-13 17:46:10','1','img/banner1.png','img/banner1.png',NULL),(2,'轮播图2','web_index_lb','2021-03-03 12:54:41','2029-07-13 17:46:09','1','img/banner2.png','img/banner2.png',NULL),(3,'轮播图3','web_index_lb','2021-03-03 12:54:41','2029-07-13 17:46:09','1','img/banner3.png','img/banner3.png',NULL),(4,'轮播图4','web_index_lb','2021-03-03 12:54:41','2029-07-13 17:46:09','1','img/banner4.png','img/banner4.png',NULL);

/*Table structure for table `tb_content` */

DROP TABLE IF EXISTS `tb_content`;

CREATE TABLE `tb_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryId` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `pic` varchar(500) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `sortOrder` int(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `tb_content` */

insert  into `tb_content`(`id`,`categoryId`,`title`,`url`,`pic`,`content`,`status`,`sortOrder`) values (1,1,'1元秒月饼','http://www.163.com','http://img10.360buyimg.com/babel/s590x470_jfs/t1/74905/33/1073/45881/5cf4fad9E5d088a29/38027cf306a69a7a.jpg!q90!cc_590x470.webp','qwerqwerqewrqwerqwerqwer','1',1),(2,1,'自行车','http://www.baidu.com','http://img1.360buyimg.com/pop/s590x470_jfs/t1/33037/16/5207/90009/5cb991bbE28dd89f4/7b435018f5639cad.jpg!q90!cc_590x470.webp','11111111122222222','1',2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
